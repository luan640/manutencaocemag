$(document).ready(function() {
  $('#tableOperadores').DataTable({
      "info": true,             // Informação sobre os registros
      "autoWidth": false,       // Desativa ajuste automático da largura
      "responsive": true        // Responsividade
  });
});

